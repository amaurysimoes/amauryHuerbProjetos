<form method="post" action="action_add.php">
   <table border="0" width="500">
      <tr>
         <td>Title</td>
         <td>:</td>
         <td><input type="text" name="title"></td>
      </tr>
      <tr>
         <td>Thumbnail</td>
         <td>:</td>
         <td><input type="text" name="thumbnail"></td>
      </tr>
      <tr>
         <td>Year</td>
         <td>:</td>
         <td><input type="text" name="year"></td>
      </tr>
      <tr>
         <td>Rating</td>
         <td>:</td>
         <td><input type="text" name="rating"></td>
      </tr>
      <tr>
         <td><input type="submit" value="SAVE"></td>
      </tr>
   </table>
</form>