<?php
$databaseURL = "https://YOURDB.firebaseio.com/";
