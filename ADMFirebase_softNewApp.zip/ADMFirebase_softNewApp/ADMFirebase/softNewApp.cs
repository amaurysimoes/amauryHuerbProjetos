﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADMFirebase
{
    internal class softNewApp
    {
        public string Cliente { get; set; }
        public string Pedido { get; set; }
        public string Quantidade { get; set; }
        public string Local { get; set; }
    }
}
